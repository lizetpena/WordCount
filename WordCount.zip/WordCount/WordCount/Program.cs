﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace WordCount
{



    class Program
    {
        private static string searchWord="lorem";
        private static string inputFilename=@"Words.txt";
        private static int searchWordOccurrence=0;
        private static int delay=10;  //ms delay

        static void Main(string[] args)
        {
            Console.WriteLine();
            Console.WriteLine("\tCounting the number of occurrences of word: {0} in {1} file...", searchWord, inputFilename);
            IEnumerable<string> lines = File.ReadAllLines(inputFilename);

            CountSearchWord(lines);
            //CountSearchWordsUsingTasks(lines);
            //CountSearchWordsUsingThreads(lines);


            Console.WriteLine("\tWord: {0} occurs {1} times.", searchWord, searchWordOccurrence);
            Console.WriteLine("\tHit any key to exit...");
            Console.ReadKey();

        }

        private static void CountSearchWordsUsingThreads(IEnumerable<string> lines)
        {
            var countDownEvent = new CountdownEvent(lines.Count());
            foreach (var line in lines)
            {
                var ln = line;
                ThreadPool.QueueUserWorkItem(o =>
                {
                    CountSearchWord(ln);
                    countDownEvent.Signal();
                });
            }
            countDownEvent.Wait();
        }

        private static void CountSearchWordsUsingTasks(IEnumerable<string> lines)
        {
            //Parallel.ForEach(lines, line => CountSearchWord(line));
            var tasks = new List<Task<int>>();
            
            foreach (var line in lines)
            {
                var t2 = Task.Run(() => CheckMatch(line));
                
                tasks.Add(t2);
                Thread.Sleep(delay);
            }
            Task.WaitAll(tasks.ToArray());
            
            foreach(var t in tasks)
            {
                if((!t.IsFaulted)&&(t.IsCompleted))
                {
                    searchWordOccurrence = searchWordOccurrence + t.Result;
                }
                
            }

        }

        private static int CheckMatch(string line)
        {
            var words = line.Split(new char[] { ' ', '\t', ',' }, StringSplitOptions.RemoveEmptyEntries);
            var occurrence = words.Where(w => string.Compare(w, searchWord, true) == 0).Count();
            return occurrence;
        }

        

        private static void CountSearchWord(IEnumerable<string> lines)
        {
            var occurrence = 0;
            foreach (var line in lines)
            {
                var words = line.Split(new char[] { ' ', '\t', ',' }, StringSplitOptions.RemoveEmptyEntries);
                occurrence=words.Where(w => string.Compare(w, searchWord, true) == 0).Count();
                Interlocked.Add(ref searchWordOccurrence, occurrence);
                Thread.Sleep(delay);
            }
            

        }

        private static void CountSearchWord(string line)
        {
                             
                var words = line.Split(new char[] { ' ', '\t', ',' }, StringSplitOptions.RemoveEmptyEntries);
                var occurrence = words.Where(w => string.Compare(w, searchWord, true) == 0).Count();
                Interlocked.Add(ref searchWordOccurrence, occurrence);
                Thread.Sleep(delay);
            


        }
    }
}
